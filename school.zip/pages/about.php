

    <!-- Header Start -->
    <?php include('common/mini_header.php'); ?>
    <!-- Header End -->

    <!-- About Start -->
    <?php include('common/about.php'); ?>
    <!-- About End -->

    <!-- Facilities Start -->
    <?php include('common/facilities.php'); ?>
    <!-- Facilities Start -->
    
    <!-- Team Start -->
    <?php include('common/team.php'); ?>
    <!-- Team End -->