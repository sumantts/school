<!-- Header Start -->
    <?php include('common/banner.php'); ?>
    <!-- Header End -->

    <!-- Facilities Start -->
    <?php include('common/facilities.php'); ?>
    <!-- Facilities Start -->

    <!-- About Start -->
    <?php include('common/about.php'); ?>
    <!-- About End -->

    <!-- Class Start -->
    <?php //include('common/popular_class.php'); ?>
    <!-- Class End -->

    <!-- Registration Start -->
    <?php include('common/registration.php'); ?>
    <!-- Registration End -->

    <!-- Team Start -->
    <?php //include('common/team.php'); ?>
    <!-- Team End -->

    <!-- Testimonial Start -->
    <?php //include('common/testimonial.php'); ?>
    <!-- Testimonial End -->

    <!-- Blog Start -->
    <?php //include('common/blog.php'); ?>
    <!-- Blog End -->