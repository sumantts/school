

    <!-- Header Start -->
    <?php include('common/mini_header.php'); ?>
    <!-- Header End -->

    <!-- About Start -->
    <?php include('common/team.php'); ?>
    <!-- About End -->
    
    <!-- Team Start -->
    <?php include('common/testimonial.php'); ?>
    <!-- Team End -->