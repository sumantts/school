

    <!-- Header Start -->
    <?php include('common/mini_header.php'); ?>
    <!-- Header End -->

    <!-- About Start -->
    <?php include('common/popular_class.php'); ?>
    <!-- About End -->
    
    <!-- Team Start -->
    <?php include('common/registration.php'); ?>
    <!-- Team End -->