<?php
	include('../../assets/php/sql_conn.php');
	$fn = '';
    
	if(isset($_GET["fn"])){
	    $fn = $_GET["fn"];
	}else if(isset($_POST["fn"])){
	    $fn = $_POST["fn"];
	}

	//Save function start
	if($fn == 'saveFormData'){
		$return_result = array();
		$status = true;

		$author_id = $_POST["author_id"];	
		$author_name = $_POST["author_name"];
		$author_bio = $_POST["author_bio"];	
		$author_photo = $_POST["author_photo"];	
		$author_status = $_POST["author_status"];
		$facebook_link = $_POST["facebook_link"];
		$linkedin_link = $_POST["linkedin_link"];
		$instagram_link = $_POST["instagram_link"];
		
		try {
			if($author_id > 0){
				$status = true;
				$sql = "UPDATE author_details SET author_name = '" .$author_name. "', author_bio = '" .$author_bio. "', author_photo = '" .$author_photo. "', author_status = '" .$author_status. "', facebook_link = '" .$facebook_link. "', linkedin_link = '" .$linkedin_link. "', instagram_link = '" .$instagram_link. "' WHERE author_id = '" .$author_id. "' ";
				$result = $mysqli->query($sql);
			}else{
				$sql = "INSERT INTO author_details (author_name, author_bio, author_photo, facebook_link, linkedin_link, instagram_link) VALUES ('" .$author_name. "', '" .$author_bio. "', '" .$author_photo. "', '" .$facebook_link. "', '" .$linkedin_link. "', '" .$instagram_link. "')";
				$result = $mysqli->query($sql);
				$insert_id = $mysqli->insert_id;
				if($insert_id > 0){
					$status = true;
				}else{
					$return_result['error_message'] = 'Photo size is soo large';
					$status = false;
				}		
			}	
		} catch (PDOException $e) {
			die("Error occurred:" . $e->getMessage());
		}
		$return_result['status'] = $status;
		sleep(2);
		echo json_encode($return_result);
	}//Save function end	

	//function start
	if($fn == 'getTableData'){
		$return_array = array();
		$status = true;
		$mainData = array();
		$author_bio1 = '';
		$sql = "SELECT * FROM author_details";
		$result = $mysqli->query($sql);

		if ($result->num_rows > 0) {
			$status = true;
			$slno = 1;
			while($row = $result->fetch_array()){
				$author_id = $row['author_id'];			
				$author_name = $row['author_name'];		
				$author_bio = $row['author_bio'];	
				if($row['author_photo'] != ''){
					$author_photo = $row['author_photo'];
				}else{
					$author_photo = '';
				}	
				$author_status = ucfirst($row['author_status']);	

				if(strpos($author_bio, "A") == true){
					$author_bio1 = substr($author_bio, 0, 100) . '...'; //English 100 //Bengali 300
				}else{
					$author_bio2 = substr($author_bio, 0, 300); //English 100 //Bengali 300
					$author_bio1 = substr($author_bio2, 0, -2) . '...';
				}


				$data[0] = $slno;
				$data[1] = $author_name;
				$data[2] = "<img src='".$author_photo."' id='saved_image' width='100' style='border-radius: 50px'>"; 
				$data[3] = $author_status;
				$data[4] = "<a href='javascript: void(0)' data-center_id='1'><i class='fa fa-edit' aria-hidden='true' onclick='editTableData(".$author_id.")'></i></a><a href='javascript: void(0)' data-center_id='1'> <i class='fa fa-trash' aria-hidden='true' onclick='deleteTableData(".$author_id.")'></i></a>";

				array_push($mainData, $data);
				$slno++;
			}
		} else {
			$status = false;
		}
		//$mysqli->close();

		$return_array['data'] = $mainData;
    	echo json_encode($return_array);
	}//function end	

	//function start
	if($fn == 'getFormEditData'){
		$return_array = array();
		$status = true;
		$mainData = array();
		$author_id = $_POST['author_id'];

		$sql = "SELECT * FROM author_details WHERE author_id = '" .$author_id. "'";
		$result = $mysqli->query($sql);

		if ($result->num_rows > 0) {
			$status = true;	
			$row = $result->fetch_array();
			$author_id = $row['author_id'];			
			$author_name = $row['author_name'];		
			$author_bio = $row['author_bio'];			
			$author_status = $row['author_status'];	
			if($row['author_photo'] != ''){
				$author_photo = $row['author_photo'];	
			}else{
				$author_photo = '';
			}			
			$facebook_link = $row['facebook_link'];				
			$linkedin_link = $row['linkedin_link'];				
			$instagram_link = $row['instagram_link'];	
		} else {
			$status = false;
		}
		//$mysqli->close();

		$return_array['author_name'] = $author_name;
		$return_array['author_bio'] = $author_bio;
		$return_array['author_photo'] = $author_photo;
		$return_array['author_status'] = $author_status;
		$return_array['facebook_link'] = $facebook_link;
		$return_array['linkedin_link'] = $linkedin_link;
		$return_array['instagram_link'] = $instagram_link;
		$return_array['status'] = $status;
    	echo json_encode($return_array);
	}//function end

	//Delete function
	if($fn == 'deleteTableData'){
		$return_result = array();
		$author_id = $_POST["author_id"];
		$status = true;	

		$sql = "DELETE FROM author_details WHERE author_id = '".$author_id."'";
		$result = $mysqli->query($sql);
		$return_result['status'] = $status;
		sleep(1);
		echo json_encode($return_result);
	}//end function deleteItem

?>