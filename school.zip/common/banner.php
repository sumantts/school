

    <div class="container-fluid bg-primary px-0 px-md-5 mb-3">
      <div class="row align-items-center px-3">
        <div class="col-lg-6 text-center text-lg-left">
          <h4 class="text-white mb-4 mt-5 mt-lg-0">প্লে-গ্রুপ হইতে দশম শ্রেণী পর্যন্ত</h4>
          <h1 class="display-3 font-weight-bold text-white mb-5">
            <!-- New Approach to Smart Education -->
            স্মার্ট শিক্ষার নতুন পদ্ধতি
          </h1>

          <h4 class="mb-4 mt-5 mt-lg-0">একটি আদর্শ বাংলা মাধ্যম কো-এডুকেশনাল আবাসিক ও অনাবাসিক শিক্ষা প্রতিষ্ঠান</h4>

          <!-- <img src="img/admision_on_going.png" width=200 style="margin-top: 50px;"> -->
          <!-- <h3> From Play Group to 10th Class</h3> -->
          
          <!-- <a href="" class="btn btn-secondary mt-1 py-3 px-5">Learn More</a> -->
        </div>
        <div class="col-lg-6 mb-5 text-center text-lg-right">
          <!-- <img class="img-fluid mt-5" src="img/header.png" alt="" /> -->
          <img class="img-fluid mt-5" src="img/home_banner.png" alt="" />
        </div>
      </div>
    </div>

    <div class="">
      <p class="first-slide">
        <span>&nbsp;&nbsp; ২০২৪ শিক্ষাবর্ষে প্লে -গ্রুপ (বয়স ২+) থেকে সপ্তম শ্রেণী পর্যন্ত ফর্ম দেওয়া ও ভর্তি নেওয়া চলছে  -&nbsp;</span>
      </p>
      <!-- <p class="words words--first">
        <span>2. ২০২৪ শিক্ষাবর্ষে প্লে -গ্রুপ (বয়স ২+) থেকে সপ্তম শ্রেণী পর্যন্ত ফর্ম দেওয়া ও ভর্তি নেওয়া চলছে  -&nbsp;</span>
      </p> -->
      <p class="words words--second">
        <span> ২০২৪ শিক্ষাবর্ষে প্লে -গ্রুপ (বয়স ২+) থেকে সপ্তম শ্রেণী পর্যন্ত ফর্ম দেওয়া ও ভর্তি নেওয়া চলছে  -&nbsp;</span>
      </p>
    </div>